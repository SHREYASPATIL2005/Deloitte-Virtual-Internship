import json
from datetime import datetime

# Convert ISO timestamp to milliseconds
def iso_to_millis(iso_str: str) -> int:
    dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
    return int(dt.timestamp() * 1000)

# Unify the two telemetry formats into target format
def unify_format(data):
    unified = []
    for entry in data:
        if "timestamp" in entry:  # already in millis
            ts = entry["timestamp"]
            val = entry["value"]
        elif "time" in entry:  # ISO format
            ts = iso_to_millis(entry["time"])
            val = entry["reading"]
        else:
            raise ValueError("Unknown format:", entry)

        unified.append({"timestamp": ts, "value": val})
    return unified
