import json
import main

def test_unify():
    with open("data-1.json") as f1:
        data1 = json.load(f1)
    with open("data-2.json") as f2:
        data2 = json.load(f2)
    with open("data-result.json") as f3:
        expected = json.load(f3)

    # Run transformation
    result = main.unify_format(data1) + main.unify_format(data2)

    # Save result for inspection
    with open("output.json", "w") as f:
        json.dump(result, f, indent=2)

    # Validate against expected
    assert result == expected, f"❌ Test failed!\nExpected: {expected}\nGot: {result}"
    print("✅ All tests passed! Output written to output.json")

if __name__ == "__main__":
    test_unify()
